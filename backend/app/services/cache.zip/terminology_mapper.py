"""
SajuOS 용어 치환 레이어
- 명리학 용어 → 비즈니스 언어 100% 치환
- 프롬프트 레벨 + 후처리 레벨 이중 방어

금칙어 정책:
- 사주 원국 카드(상단 표): 원어 허용 (甲乙丙丁 등)
- 컨설팅 섹션 본문: 100% 금지 및 치환
"""
import re
from typing import Dict, List, Tuple


# ============ 용어 치환 사전 ============

# 십성(十星) → 비즈니스 개념
SIPSUNG_MAP: Dict[str, List[str]] = {
    # 비겁(比劫) - 경쟁/파트너
    "비겁": ["경쟁 구도", "시장 경쟁", "파트너십 역학", "동종 업계 경쟁"],
    "비견": ["동급 경쟁자", "파트너", "협력 네트워크", "동료 자원"],
    "겁재": ["공격적 경쟁", "시장 잠식 리스크", "내부 갈등 요인", "자원 경쟁"],
    
    # 인성(印星) - 지식/브랜드
    "인성": ["지식 자산", "IP 포트폴리오", "브랜드 신뢰도", "학습 역량"],
    "정인": ["핵심 IP", "공인 자격", "안정적 브랜드", "축적된 노하우"],
    "편인": ["혁신 기술", "비공식 네트워크", "창의적 자산", "잠재 역량"],
    
    # 재성(財星) - 현금흐름/자산
    "재성": ["현금흐름", "유동성", "매출 구조", "자산 포트폴리오"],
    "정재": ["안정 수익원", "정기 매출", "핵심 자산", "예측 가능 현금흐름"],
    "편재": ["신규 수익 기회", "변동 매출", "투자 수익", "고위험 고수익 자산"],
    
    # 관성(官星) - 시스템/컴플라이언스
    "관성": ["조직 시스템", "규정 준수", "리스크 관리", "거버넌스"],
    "정관": ["공식 시스템", "법적 프레임워크", "안정적 통제", "컴플라이언스"],
    "편관": ["외부 압력", "규제 리스크", "불확실성", "위기 관리 필요"],
    "칠살": ["심각한 위협", "구조적 리스크", "긴급 대응 필요", "위기 시나리오"],
    
    # 식상(食傷) - 실행/생산
    "식상": ["실행력", "생산성", "아웃풋", "시장 진출 역량"],
    "식신": ["안정적 생산", "품질 관리", "지속 가능한 성과", "핵심 역량 발휘"],
    "상관": ["혁신적 출력", "파괴적 혁신", "공격적 마케팅", "고성장 전략"],
}

# 천간(天干) → 비즈니스 속성
CHUNGAN_MAP: Dict[str, str] = {
    "갑": "성장 주도형 리더십",
    "을": "유연한 적응 전략",
    "병": "확장적 시장 공략",
    "정": "정밀한 품질 관리",
    "무": "안정적 기반 구축",
    "기": "섬세한 고객 관리",
    "경": "단호한 의사결정",
    "신": "정교한 시스템 구축",
    "임": "대규모 네트워크 확장",
    "계": "세밀한 리스크 관리",
}

# 지지(地支) → 비즈니스 타이밍/환경
JIJI_MAP: Dict[str, str] = {
    "자": "심야/연말 집중 기간",
    "축": "기반 다지기 시기",
    "인": "성장 가속 시기",
    "묘": "확장 본격화 시기",
    "진": "변화 전환점",
    "사": "최고조 퍼포먼스 시기",
    "오": "정점/피크 시즌",
    "미": "수확/정산 시기",
    "신": "구조조정 시기",
    "유": "수익 실현 시기",
    "술": "마무리/점검 시기",
    "해": "재정비/준비 시기",
}

# 오행(五行) → 비즈니스 영역
OHANG_MAP: Dict[str, str] = {
    "목": "성장/확장 영역",
    "화": "마케팅/브랜딩 영역",
    "토": "운영/관리 영역",
    "금": "재무/수익 영역",
    "수": "전략/기획 영역",
    "木": "성장/확장 영역",
    "火": "마케팅/브랜딩 영역",
    "土": "운영/관리 영역",
    "金": "재무/수익 영역",
    "水": "전략/기획 영역",
}

# 기타 명리학 용어 → 비즈니스 표현
MISC_MAP: Dict[str, str] = {
    "대운": "장기 트렌드 사이클",
    "세운": "연간 비즈니스 환경",
    "월운": "월별 시장 흐름",
    "일운": "일별 실행 리듬",
    "용신": "핵심 성공 요인(CSF)",
    "희신": "보조 성공 요인",
    "기신": "주요 리스크 요인",
    "구신": "잠재적 위협 요인",
    "격국": "비즈니스 모델 유형",
    "신강": "내부 역량 우위",
    "신약": "외부 자원 의존",
    "일간": "핵심 의사결정자 특성",
    "일주": "리더십 프로파일",
    "월주": "사업 환경 특성",
    "년주": "시장 진입 배경",
    "시주": "성과 창출 패턴",
    "천간": "전략적 방향성",
    "지지": "실행 환경",
    "간지": "전략-실행 조합",
    "사주": "비즈니스 DNA",
    "팔자": "핵심 역량 프로파일",
    "명리": "데이터 기반 분석",
    "운세": "시장 전망",
    "길흉": "기회와 위협",
    "합": "시너지 효과",
    "충": "갈등/마찰 요인",
    "형": "구조적 긴장",
    "파": "일시적 충돌",
    "해": "잠재적 손실",
    "원진": "장기 경쟁 관계",
    "귀문관살": "예외적 리스크 시나리오",
    "도화": "대외 이미지/PR 역량",
    "역마": "확장/이동/글로벌 기회",
    "화개": "전문성/니치 마켓",
    "문창": "콘텐츠/교육 역량",
    "천을귀인": "핵심 멘토/후원자 네트워크",
    "월덕귀인": "안정적 지원 시스템",
}

# 간지 60갑자 패턴 (본문에서 제거/치환)
GANJI_60 = [
    "갑자", "을축", "병인", "정묘", "무진", "기사", "경오", "신미", "임신", "계유",
    "갑술", "을해", "병자", "정축", "무인", "기묘", "경진", "신사", "임오", "계미",
    "갑신", "을유", "병술", "정해", "무자", "기축", "경인", "신묘", "임진", "계사",
    "갑오", "을미", "병신", "정유", "무술", "기해", "경자", "신축", "임인", "계묘",
    "갑진", "을사", "병오", "정미", "무신", "기유", "경술", "신해", "임자", "계축",
    "갑인", "을묘", "병진", "정사", "무오", "기미", "경신", "신유", "임술", "계해",
]


# ============ 금칙어 패턴 ============

FORBIDDEN_PATTERNS = [
    # 십성 관련
    r'비겁운', r'인성운', r'재성운', r'관성운', r'식상운',
    r'비견이', r'겁재가', r'정인이', r'편인이',
    r'정재가', r'편재가', r'정관이', r'편관이', r'칠살이',
    r'식신이', r'상관이',
    
    # 오행 관련
    r'목기', r'화기', r'토기', r'금기', r'수기',
    r'목의 기운', r'화의 기운', r'토의 기운', r'금의 기운', r'수의 기운',
    
    # 간지 직접 언급
    r'[갑을병정무기경신임계][자축인묘진사오미신유술해](?:년|월|일|시)?',
    
    # 명리학 전문 표현
    r'사주[가는을를]', r'팔자[가는을를]',
    r'운세[가는을를이]',
    r'명리학', r'명리적',
    r'음양오행',
    r'천간지지',
    r'대운이', r'세운이', r'월운이',
    r'용신이', r'희신이', r'기신이',
    r'격국이', r'신강', r'신약',
    r'합이', r'충이', r'형이', r'파가', r'해가',
    
    # 한자 표현
    r'[甲乙丙丁戊己庚辛壬癸]',
    r'[子丑寅卯辰巳午未申酉戌亥]',
    r'[木火土金水]',
]


# ============ 치환 함수 ============

def replace_sipsung(text: str) -> str:
    """십성 용어를 비즈니스 용어로 치환"""
    result = text
    for saju_term, business_terms in SIPSUNG_MAP.items():
        # 다양한 형태로 치환 (문맥에 맞게 첫 번째 또는 랜덤)
        business_term = business_terms[0]
        
        # "OO운" 패턴
        result = re.sub(
            rf'{saju_term}운',
            f'{business_term} 사이클',
            result
        )
        # "OO이/가" 패턴
        result = re.sub(
            rf'{saju_term}[이가은는을를]',
            f'{business_term}이 ',
            result
        )
        # 단독 사용
        result = re.sub(
            rf'\b{saju_term}\b',
            business_term,
            result
        )
    
    return result


def replace_misc_terms(text: str) -> str:
    """기타 명리학 용어 치환"""
    result = text
    for saju_term, business_term in MISC_MAP.items():
        result = re.sub(
            rf'\b{saju_term}\b',
            business_term,
            result
        )
    return result


def replace_ohang(text: str) -> str:
    """오행 용어 치환"""
    result = text
    for saju_term, business_term in OHANG_MAP.items():
        result = re.sub(
            rf'{saju_term}[의에]?\s*기운',
            business_term,
            result
        )
        result = re.sub(
            rf'\b{saju_term}기\b',
            business_term,
            result
        )
    return result


def remove_ganji_references(text: str) -> str:
    """60갑자 직접 참조 제거 (문맥 파괴 없이)"""
    result = text
    for ganji in GANJI_60:
        # "OO년/월/일" 형태는 "해당 시기"로 치환
        result = re.sub(
            rf'{ganji}(?:년|월|일)',
            '해당 시기',
            result
        )
        # 단독 사용은 제거
        result = re.sub(
            rf'\b{ganji}\b',
            '',
            result
        )
    return result


def remove_forbidden_patterns(text: str) -> str:
    """금칙어 패턴 제거/치환"""
    result = text
    for pattern in FORBIDDEN_PATTERNS:
        result = re.sub(pattern, '', result)
    
    # 빈 괄호, 연속 공백 정리
    result = re.sub(r'\(\s*\)', '', result)
    result = re.sub(r'\s{2,}', ' ', result)
    result = re.sub(r'\n{3,}', '\n\n', result)
    
    return result.strip()


def sanitize_for_business(text: str, aggressive: bool = True) -> str:
    """
    명리학 용어를 비즈니스 용어로 전환하는 메인 함수
    
    Args:
        text: 원본 텍스트
        aggressive: True면 강력 치환, False면 부드러운 치환
    
    Returns:
        치환된 비즈니스 텍스트
    """
    if not text:
        return text
    
    result = text
    
    # 🔥 P0: RC-#### 내부 메모 제거 (프론트 노출 금지)
    result = re.sub(r'RC-\d{4}', '', result)
    result = re.sub(r'\[RC-\d{4}\]', '', result)
    result = re.sub(r'\(RC-\d{4}\)', '', result)
    
    # 🔥 P0: 추상어 제거 (일반론 금지)
    abstract_phrases = [
        r'노력하세요', r'노력이 필요합니다', r'노력해야 합니다',
        r'성장의 시기', r'성장기', r'발전의 시기',
        r'균형을 유지', r'균형이 중요', r'균형 잡힌',
        r'좋은 운', r'운이 좋', r'행운',
        r'주의가 필요', r'조심해야', r'유의하세요',
    ]
    for phrase in abstract_phrases:
        result = re.sub(phrase, '', result)
    
    # 1단계: 십성 치환 (가장 중요)
    result = replace_sipsung(result)
    
    # 2단계: 기타 명리 용어 치환
    result = replace_misc_terms(result)
    
    # 3단계: 오행 치환
    result = replace_ohang(result)
    
    # 4단계: 60갑자 참조 제거
    if aggressive:
        result = remove_ganji_references(result)
    
    # 5단계: 금칙어 최종 제거
    result = remove_forbidden_patterns(result)
    
    # 6단계: 정리 (연속 공백, 빈 줄)
    result = re.sub(r'\s{2,}', ' ', result)
    result = re.sub(r'\n{3,}', '\n\n', result)
    result = result.strip()
    
    return result


def get_business_prompt_rules() -> str:
    """GPT 프롬프트에 포함할 용어 규칙"""
    return """
## 🚨 필수 용어 규칙 (위반 시 재작성)

### 절대 금지 용어 (본문에 사용 금지)
- 십성: 비겁, 비견, 겁재, 인성, 정인, 편인, 재성, 정재, 편재, 관성, 정관, 편관, 칠살, 식상, 식신, 상관
- 간지: 갑을병정무기경신임계 + 자축인묘진사오미신유술해 조합 (예: 갑자, 을축, 병인, 정사, 무인 등)
- 명리학 용어: 사주, 팔자, 운세, 명리, 음양오행, 천간지지, 대운, 세운, 월운, 용신, 희신, 기신, 격국, 신강, 신약, 합충형파해
- 한자 표기: 甲乙丙丁戊己庚辛壬癸, 子丑寅卯辰巳午未申酉戌亥, 木火土金水

### 필수 치환 규칙
| 명리 용어 | → 비즈니스 용어 |
|-----------|-----------------|
| 비겁/비견/겁재 | 경쟁 구도, 파트너십 역학, 시장 경쟁 |
| 인성/정인/편인 | 지식 자산, IP, 브랜드 신뢰도, 학습 역량 |
| 재성/정재/편재 | 현금흐름, 유동성, 매출 구조, 자산 |
| 관성/정관/편관 | 조직 시스템, 컴플라이언스, 리스크 관리 |
| 식상/식신/상관 | 실행력, 생산성, 마케팅, 기술혁신 |
| 용신 | 핵심 성공 요인(CSF) |
| 대운/세운 | 장기/연간 비즈니스 사이클 |
| 길흉 | 기회와 위협 |

### 작성 톤
- 맥킨지/BCG 컨설팅 보고서 스타일
- 데이터 기반, 실행 가능한 제안
- 구체적 숫자, 날짜, KPI 명시
- 사주 풀이가 아닌 '경영 전략 보고서'
"""


def validate_no_forbidden_terms(text: str) -> Tuple[bool, List[str]]:
    """
    텍스트에 금칙어가 있는지 검증
    
    Returns:
        (통과 여부, 발견된 금칙어 리스트)
    """
    found_terms = []
    
    # 십성 체크
    for term in SIPSUNG_MAP.keys():
        if term in text:
            found_terms.append(f"십성:{term}")
    
    # 60갑자 체크
    for ganji in GANJI_60:
        if ganji in text:
            found_terms.append(f"간지:{ganji}")
    
    # 기타 명리 용어 체크
    for term in list(MISC_MAP.keys())[:20]:  # 주요 용어만
        if term in text and term not in ["합", "파"]:  # 일반 단어 제외
            found_terms.append(f"명리:{term}")
    
    # 한자 체크
    hanja_pattern = r'[甲乙丙丁戊己庚辛壬癸子丑寅卯辰巳午未申酉戌亥木火土金水]'
    if re.search(hanja_pattern, text):
        found_terms.append("한자 발견")
    
    return len(found_terms) == 0, found_terms


# ============ 테스트 ============

if __name__ == "__main__":
    test_text = """
    2026년에는 비겁운이 강하게 작용하여 경쟁이 치열해집니다.
    정재가 들어오는 시기이므로 재물운이 좋습니다.
    무인년의 영향으로 식상이 활발해져 창작 활동에 유리합니다.
    대운에서 정관이 들어와 직장에서 승진 기회가 있습니다.
    """
    
    print("=== 원본 ===")
    print(test_text)
    print("\n=== 치환 후 ===")
    print(sanitize_for_business(test_text))
    
    print("\n=== 검증 ===")
    is_valid, found = validate_no_forbidden_terms(test_text)
    print(f"원본 검증: 통과={is_valid}, 발견={found}")
    
    sanitized = sanitize_for_business(test_text)
    is_valid2, found2 = validate_no_forbidden_terms(sanitized)
    print(f"치환후 검증: 통과={is_valid2}, 발견={found2}")
