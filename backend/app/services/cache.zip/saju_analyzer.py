# app/services/saju_analyzer.py
from typing import Dict, Any

ELEMENTS = ["목","화","토","금","수"]
TEN_GROUPS = ["비겁","식상","재성","관성","인성"]

def get_saju_summary(saju_data: Dict[str, Any]) -> Dict[str, Any]:
    """
    saju_data는 calc_module/engine_v2 결과(dict)라고 가정:
    - year/month/day/hour 각각 gan_element, ji_element, ten_god(있으면) 등을 포함
    """
    elements_count = {e: 0 for e in ELEMENTS}

    def add_elements(pillar: Dict[str, Any]):
        if not pillar: 
            return
        ge = pillar.get("gan_element")
        je = pillar.get("ji_element")
        if ge in elements_count: elements_count[ge] += 1
        if je in elements_count: elements_count[je] += 1

    for k in ["year","month","day","hour"]:
        add_elements((saju_data.get(k) or {}))

    # 십성 분포: 엔진이 ten_god를 주면 그걸 집계, 없으면(현재 코드 상태에 따라) 그룹만 비워두고 룰카드로만 운영
    ten_gods_distribution = {g: 0 for g in TEN_GROUPS}
    for k in ["year","month","day","hour"]:
        p = saju_data.get(k) or {}
        tg = p.get("ten_god_group")  # 예: "식상" 같은 그룹값을 엔진이 주는 형태 추천
        if tg in ten_gods_distribution:
            ten_gods_distribution[tg] += 1

    summary = {
        "elements_count": elements_count,
        "ten_gods_distribution": ten_gods_distribution,
        "is_missing_shiksang": ten_gods_distribution.get("식상", 0) == 0,
        "day_master": (saju_data.get("day") or {}).get("gan"),
        "primary_structure": None,   # 아래 constants/로직으로 채움
        "year_impact": [],           # 2026 영향이 계산된 경우만 채움
    }
    return summary
